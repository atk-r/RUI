// @generated using 'yarn generate:icons'
// from https://www.figma.com/file/ECpK9PAYqlU84n8MlhnaXV/RUI-Design-System?node-id=237%3A9445

import React from "react";
import Icon, { Props as IconProps } from "./Icon";

export default function ChevronRightIcon(props: IconProps) {
  return (
    <Icon {...props}>
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M15.5303 11.4697C15.8232 11.7626 15.8232 12.2374 15.5303 12.5303L9.53033 18.5303C9.23744 18.8232 8.76256 18.8232 8.46967 18.5303C8.17678 18.2374 8.17678 17.7626 8.46967 17.4697L13.9393 12L8.46967 6.53033C8.17678 6.23744 8.17678 5.76256 8.46967 5.46967C8.76256 5.17678 9.23744 5.17678 9.53033 5.46967L15.5303 11.4697Z"
      />
    </Icon>
  );
}
