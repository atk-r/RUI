// @generated using 'yarn generate:icons'
// from https://www.figma.com/file/ECpK9PAYqlU84n8MlhnaXV/RUI-Design-System?node-id=237%3A9440

import React from "react";
import Icon, { Props as IconProps } from "./Icon";

export default function ChevronDownIcon(props: IconProps) {
  return (
    <Icon {...props}>
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M12.5303 15.5303C12.2374 15.8232 11.7626 15.8232 11.4697 15.5303L5.46967 9.53033C5.17678 9.23744 5.17678 8.76256 5.46967 8.46967C5.76256 8.17678 6.23744 8.17678 6.53033 8.46967L12 13.9393L17.4697 8.46967C17.7626 8.17678 18.2374 8.17678 18.5303 8.46967C18.8232 8.76256 18.8232 9.23744 18.5303 9.53033L12.5303 15.5303Z"
      />
    </Icon>
  );
}
